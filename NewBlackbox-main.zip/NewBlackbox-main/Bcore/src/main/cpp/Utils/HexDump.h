



#ifndef SPEED_HEXDUMP_H
#define SPEED_HEXDUMP_H


class HexDump {

};
void HexDump(char *buf, int len, int addr);

#endif 
