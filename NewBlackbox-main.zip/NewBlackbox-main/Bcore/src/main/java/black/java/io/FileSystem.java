package black.java.io;


import top.niunaijun.blackreflection.annotation.BClassName;

@BClassName("java.io.FileSystem")
public interface FileSystem {
}
