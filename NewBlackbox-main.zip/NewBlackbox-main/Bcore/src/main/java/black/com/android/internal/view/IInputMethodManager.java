package black.com.android.internal.view;


import top.niunaijun.blackreflection.annotation.BClassName;

@BClassName("com.android.internal.view.IInputMethodManager")
public interface IInputMethodManager {
}
