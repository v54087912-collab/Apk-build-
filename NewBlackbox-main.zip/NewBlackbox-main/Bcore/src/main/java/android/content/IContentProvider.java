package android.content;

import android.os.IInterface;


public interface IContentProvider extends IInterface {
}
