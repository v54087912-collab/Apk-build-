package top.niunaijun.blackbox.core.system;


public interface ISystemService {
    void systemReady();
}
